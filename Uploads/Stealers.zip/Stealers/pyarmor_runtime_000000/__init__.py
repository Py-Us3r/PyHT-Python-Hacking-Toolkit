# Pyarmor 9.1.2 (trial), 000000, 2025-05-03T15:55:46.502381
from .pyarmor_runtime import __pyarmor__
