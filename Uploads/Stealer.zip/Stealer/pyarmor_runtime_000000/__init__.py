# Pyarmor 9.1.2 (trial), 000000, 2025-05-04T13:36:01.045397
from .pyarmor_runtime import __pyarmor__
