# Pyarmor 9.1.2 (trial), 000000, 2025-05-04T14:24:30.767612
from .pyarmor_runtime import __pyarmor__
