# Pyarmor 9.1.2 (trial), 000000, 2025-05-04T20:56:51.278757
from .pyarmor_runtime import __pyarmor__
